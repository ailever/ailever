import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import statsmodels.tsa.api as smt
from scipy import stats

def stationary(TS, title=None):
    """
    Augmented Dickey-Fuller test

    Null Hypothesis (H0): [if p-value > 0.5, non-stationary]
    >   Fail to reject, it suggests the time series has a unit root, meaning it is non-stationary.
    >   It has some time dependent structure.
    Alternate Hypothesis (H1): [if p-value =< 0.5, stationary]
    >   The null hypothesis is rejected; it suggests the time series does not have a unit root, meaning it is stationary.
    >   It does not have time-dependent structure.
    """
    result = smt.adfuller(TS)

    print(f'* {title}')
    print(f'[ADF Statistic] : {result[0]}')
    print(f'[p-value] : {result[1]}')
    for key, value in result[4].items():
        print(f'[Critical Values {key} ] : {value}')
    print()


def tsplot(TS, lags=None, figsize=(18, 20), style='bmh'):
    if not isinstance(TS, pd.Series):
        TS = pd.Series(TS)

    with plt.style.context(style):
        fig = plt.figure(figsize=figsize)
        # mpl.rcParams['font.family'] = 'Ubuntu Mono'

        layout = (6, 2)
        ts_ax = plt.subplot2grid(layout, (0, 0), colspan=2)
        dc_trend_ax = plt.subplot2grid(layout, (1, 0), colspan=2)
        dc_seasonal_ax = plt.subplot2grid(layout, (2, 0), colspan=2)
        dc_resid_ax = plt.subplot2grid(layout, (3, 0), colspan=2)
        acf_ax = plt.subplot2grid(layout, (4, 0))
        pacf_ax = plt.subplot2grid(layout, (4, 1))
        qq_ax = plt.subplot2grid(layout, (5, 0))
        pp_ax = plt.subplot2grid(layout, (5, 1))


        TS.plot(ax=ts_ax)
        ts_ax.set_title('Time Series')
        smt.seasonal_decompose(TS, model='additive', freq=10).trend.plot(ax=dc_trend_ax)
        dc_trend_ax.set_title('[Decompose] Time Series Trend')
        smt.seasonal_decompose(TS, model='additive', freq=10).seasonal.plot(ax=dc_seasonal_ax)
        dc_seasonal_ax.set_title('[Decompose] Time Series Seasonal')
        smt.seasonal_decompose(TS, model='additive', freq=10).resid.plot(ax=dc_resid_ax)
        dc_resid_ax.set_title('[Decompose] Time Series Resid')
        smt.graphics.plot_acf(TS, lags=lags, ax=acf_ax, alpha=0.5)
        smt.graphics.plot_pacf(TS, lags=lags, ax=pacf_ax, alpha=0.5)
        sm.qqplot(TS, line='s', ax=qq_ax)
        qq_ax.set_title('QQ Plot')
        stats.probplot(TS, sparams=(TS.mean(), TS.std()), plot=pp_ax)

        plt.tight_layout()
        plt.savefig('time_series_analysis.png')
        plt.show()


#%% generate samples
num_samples = 250
seasonal_period = 10

np.random.seed(12345)
arparams = np.array([.75, -.25, -.43])
maparams = np.array([.65, .35])

ar = np.r_[1, -arparams] # add zero-lag and negate
ma = np.r_[1, maparams] # add zero-lag

stationary_process = smt.arma_generate_sample(ar, ma, nsample=num_samples)
stationary(stationary_process, title='stationary_process')
trend = np.array([ 0.1*i for i in range(num_samples)])
stationary(trend, title='trend')
seasonal = np.array([ np.sin(2*np.pi*i/seasonal_period) for i in range(num_samples)])
stationary(seasonal, title='seasonal')

y = trend + seasonal + stationary_process
index = pd.date_range(start='2020-01-01', freq="D", periods=num_samples)
time_series = pd.Series(y, index=index)
stationary(time_series, title='time_series')

tsplot(time_series)
print(time_series, len(time_series))



#%% [1] detrend
_, axes = plt.subplots(4,1)
smt.graphics.plot_acf(time_series, lags=50, alpha=0.5, ax=axes[0])
smt.graphics.plot_acf(time_series.diff().dropna(), lags=50, alpha=0.5, ax=axes[1])
smt.graphics.plot_acf(time_series.diff().diff().dropna(), lags=50, alpha=0.5, ax=axes[2])
smt.graphics.plot_acf(time_series.diff().diff().diff().dropna(), lags=50, alpha=0.5, ax=axes[3])
plt.show()

#%% [2] detrend
Del_T_TS = time_series.diff().diff().diff().diff().dropna()
tsplot(Del_T_TS)

#%% [1] deseasonal
_, axes = plt.subplots(4,1)
smt.graphics.plot_pacf(Del_T_TS, alpha=0.5, ax=axes[0])
smt.graphics.plot_pacf(Del_T_TS.diff(periods=21).dropna(), alpha=0.5, ax=axes[1])
smt.graphics.plot_pacf(Del_T_TS.diff(periods=21).diff(periods=12).dropna(), alpha=0.5, ax=axes[2])
smt.graphics.plot_pacf(Del_T_TS.diff(periods=21).diff(periods=12).diff(periods=10).dropna(), alpha=0.5, ax=axes[3])
plt.show()

#%% [2] deseasonal
Del_TS_TS = Del_T_TS.diff(periods=21).diff(periods=12).diff(periods=10).dropna()
tsplot(Del_TS_TS)

#%% stationary
stationary(Del_T_TS, title='del - trend')
stationary(Del_TS_TS, title='del - trend, seasonal')
Final_TS = Del_TS_TS



#%% Final Time Series Analysis
_, axes = plt.subplots(2,1)
smt.graphics.plot_acf(Final_TS, alpha=0.5, ax=axes[0])
smt.graphics.plot_pacf(Final_TS, alpha=0.5, ax=axes[1])
plt.show()

ardegree = 4
madegree = 0



#%% fit model
model = smt.arima.ARIMA(Final_TS, order=(ardegree, 0, madegree), trend='n').fit()
print(model.summary())

"""
#%% fit model : summary comparison with ideal
estimated_params = model.params
estimated_arparams = estimated_params[:ardegree]
estimated_maparams = estimated_params[ardegree : ardegree+madegree]
print('* AR params \n: ', estimated_arparams)
print('* MA params \n: ', estimated_maparams)

ar = np.r_[1, estimated_arparams]
ma = np.r_[1, estimated_maparams]
ideal_process = smt.ArmaProcess(ar, ma)
ideal_TS = ideal_process.generate_sample(500)
ideal_result = smt.arima.ARIMA(ideal_TS, order=(len(estimated_arparams), 0, len(estimated_maparams)), trend='n').fit()
print(ideal_result.summary())
"""



#%% predict
forecasting_step = 20
data = model.predict(start=num_samples-1, end=num_samples-1+forecasting_step)
print(data)

data = model.forecast(steps=forecasting_step)
print(data)



#%% visualization
fig = plt.figure()
ax = fig.add_subplot(1,1,1)
model.predict(start=0, end=num_samples-1).plot(ax=ax)
sm.graphics.tsa.plot_predict(model, start=num_samples-1, end=num_samples-1+forecasting_step, ax=ax)
plt.grid(True)
plt.savefig('forecasting.png')
plt.show()


