pyuic5 ailever.ui -o UIAilever.py
