from .DETECTIONInterfaces import dashboard
