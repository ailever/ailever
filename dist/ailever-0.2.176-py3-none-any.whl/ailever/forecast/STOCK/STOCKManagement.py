
def Ailf_KR(Df=None, ADf=None, filter_period=300, regressor_criterion=1.5, seasonal_criterion=0.1, GC=False, V='KS11', download=False):
    from ._ailf_kr import Ailf_KR
    return Ailf_KR(Df=None, ADf=None, filter_period=300, regressor_criterion=1.5, seasonal_criterion=0.1, GC=False, V='KS11', download=False)
