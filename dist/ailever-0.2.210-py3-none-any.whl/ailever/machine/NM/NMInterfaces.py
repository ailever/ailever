def softmax(X):
    from ._softmax import softmax
    return softmax(X)

def MP(X):
    from ._ascii_mapper import mapper
    return mapper(X)

