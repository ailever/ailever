class Forecaster:
    pass
