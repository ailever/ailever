
class Evaluation:
    def __init__(self):
        pass

    @staticmethod
    def classification(y_true, y_pred):
        pass

    @staticmethod
    def regression(y_true, y_pred):
        pass
    
    def imputation(self):
        pass

    def imbalance(self):
        pass

    def reduction(self):
        pass

    def linearity(self):
        pass
