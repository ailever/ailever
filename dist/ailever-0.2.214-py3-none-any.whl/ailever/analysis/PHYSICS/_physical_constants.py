physical_constants = dict()
physical_constants['reduced planck constant'] = 1.054571
physical_constants['planck constant'] = 6.626070
physical_constants['vacuum electric permittivity'] = 8.854187
physical_constants['elementary charge'] = 1.602176
physical_constants['avogadro constant'] = 6.022140
