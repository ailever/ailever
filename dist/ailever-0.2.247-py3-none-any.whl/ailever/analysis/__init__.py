from .ANALYSISInterfaces import EDA
