from .APPSManagement import eyes
from .APPSManagement import brain
#from .app_eyes import eyes
#from .app_brain import brain
