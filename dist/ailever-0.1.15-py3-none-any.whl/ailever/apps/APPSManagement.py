def eyes():
    from .app_eyes import eyes

def brain():
    from .app_brain import brain
