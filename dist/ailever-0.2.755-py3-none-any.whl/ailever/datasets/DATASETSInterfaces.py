from .uci_machine_learning_repository import UCI_MLR

UCI = UCI_MLR()


