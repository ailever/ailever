
class DataControlBlock:
    def __init__(self, frames):
        pass
