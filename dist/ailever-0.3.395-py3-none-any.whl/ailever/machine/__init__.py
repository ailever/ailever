from .MACHINEInterfaces import mapper

