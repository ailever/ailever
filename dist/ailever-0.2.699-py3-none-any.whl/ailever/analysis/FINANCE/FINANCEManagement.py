def InfluenceDiagram(labels, source, target, value, title="Influence Diagram", returnTrue=False):
    from ._influence_diagram import InfluenceDiagram
    InfluenceDiagram(labels=labels, source=source, target=target, value=value, title=title, returnTrue=returnTrue)

