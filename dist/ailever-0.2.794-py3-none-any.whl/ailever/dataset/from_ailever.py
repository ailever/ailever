
class Integrated_Loader:
    def __init__(self):
        pass
