def softmax(X):
    from ._softmax import softmax
    return softmax(X)


