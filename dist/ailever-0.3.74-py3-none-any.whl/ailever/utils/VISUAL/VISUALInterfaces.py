def hbar(LEVELs, title='title', returnTrue=False):
    from ._hbar import visualize
    return visualize(LEVELs=LEVELs, title=title, returnTrue=returnTrue)

