import numpy as np
import matplotlib.pyplot as plt

class CAPM:
    # Capital asset pricing model
    pass
