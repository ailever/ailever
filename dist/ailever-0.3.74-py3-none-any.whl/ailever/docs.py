def introduction():
    print('Promulgate values for a better tomorrow.')
