from .INVESTMENTInterfaces import parallelize
from .INVESTMENTInterfaces import reits_screening



