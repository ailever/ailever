"""
In order to get the below configs, you should be visiting the ENDPOINT_URL
that provides ID and KEY
Warnings: everytime you revisit the url, the id and key will be regenerated
unless you set up environment variables into your OS
"""

API_KEY_ID = 'PKLVJJKWN5FH3OD8VXAO'
SECRET_KEY = 'Gu8drGLHEzP2yGRXHRB9zRkL9c0LLf7bfnqoHNO2'
ENDPOINT_URL = 'https://paper-api.alpaca.markets'
DATA_URL = 'https://data.alpaca.markets'
