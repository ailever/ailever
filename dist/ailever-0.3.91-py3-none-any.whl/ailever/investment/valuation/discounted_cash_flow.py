def DiscountedCashFlow():
    operating_value = None

    ebit = None # EBIT : earnings_before_interest_and_tax
    depreciation = None
    amortization = None
    capital_expenditure = None
    changes_in_working_capital = None
    free_cash_flow = ebit + 
    
    operating_value = cumulative_present_value + present_value_of_terminal_value
    non_operating_aseet = None
    enterprise_value = operating_value + non_operating_asset
    return enterprise_value
