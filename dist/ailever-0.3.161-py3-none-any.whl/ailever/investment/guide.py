from urllib.request import urlretrieve

def guide():
    pass



urlretrieve(, )
