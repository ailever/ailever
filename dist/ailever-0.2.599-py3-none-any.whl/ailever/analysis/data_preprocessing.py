
class DataPreprocessor:
    def time_splitor():
        pass

    def missing_value():
        pass

