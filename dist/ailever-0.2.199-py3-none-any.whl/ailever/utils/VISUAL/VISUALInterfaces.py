def hbar(LEVELs, returnTrue=False):
    from ._hbar import visualize
    return visualize(LEVELs=LEVELs, returnTrue=returnTrue)

