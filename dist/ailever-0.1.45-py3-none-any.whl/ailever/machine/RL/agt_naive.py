from ._agent import BaseAgent

class NaiveAgent(BaseAgent):
    def __init__(self):
        pass

    def _setup_policy(self):
        pass

    def _setup_Q(self):
        pass

    def micro_update_Q(self):
        pass
 
    def macro_update_Q(self):
        pass

    def judge(self):
        pass

