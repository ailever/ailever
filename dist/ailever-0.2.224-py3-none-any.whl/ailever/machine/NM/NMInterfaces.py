from ._dashboard import dashboard

def softmax(X):
    from ._softmax import softmax
    return softmax(X)


