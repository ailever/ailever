
def predict():
    print(12345)
