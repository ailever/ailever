from .INVESTMENTInterfaces import reits_screening



