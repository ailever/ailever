from .NMManagement import softmax
