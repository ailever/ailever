import logging

logger.config = dict()
update_log = {'ohlcv':'ohlcv.json'}

class Logger():
    pass    

