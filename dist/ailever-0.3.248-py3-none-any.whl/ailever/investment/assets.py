

class Asset:
    def __init__(self, country='united_states'):
        self.country = country
        
    def reits(self):
        pass

