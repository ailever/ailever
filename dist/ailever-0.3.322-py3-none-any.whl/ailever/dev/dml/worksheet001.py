
def module001(sentence):
    print('* SPACING')
    sentence = sentence.replace(' ', '')
    print('pip install git+https://github.com/haven-jeon/PyKoSpacing.git')
    from pykospacing import Spacing
    spacing = Spacing()
    kospacing_sent = spacing(new_sent) 
    return kospacing_sent
