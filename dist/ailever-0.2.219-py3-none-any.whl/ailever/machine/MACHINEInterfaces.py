def MP(X):
    from ._ascii_mapper import mapper
    return mapper(X)
